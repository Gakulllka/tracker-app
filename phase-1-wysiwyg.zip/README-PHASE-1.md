# Phase 1 — WYSIWYG для презентации

Что сделано в этом патче:

- **Создан единый рендерер слайдов** (`src/lib/presentation-renderer.tsx`) — один React-компонент `<PresentationSlide />` рендерит слайд **и в превью, и в экспортируемом HTML**.
- **Создан экспорт-модуль** (`src/lib/presentation-export.tsx`) — берёт ровно те же React-компоненты и превращает в standalone HTML через `renderToStaticMarkup`. Никаких дублей логики.
- **`src/app/page.tsx` обновлён**:
  - локальный `interface SlideData` удалён, теперь импортируется из renderer'а
  - `SlidePreview` ужат с ~390 строк до ~50 — стал тонким wrapper'ом над `<PresentationSlide />`
  - локальная функция `buildSlidesHTML` (~330 строк) удалена; экспорт теперь делается через `renderPresentationHtml(...)`
  - в сумме `page.tsx` стал короче на **674 строки**
- Файл `src/lib/slides.ts` (старый orphan, не использовался) — нужно удалить руками (см. шаг 4 ниже).

---

## Что это даёт

- **Preview ≡ Export пиксель-в-пиксель.** Это была главная боль: то, что юзер видит в приложении, и то, что он скачивает — теперь буквально один и тот же React-код.
- Поправил один TypeScript-баг по дороге (`'unknown'` to `ReactNode` на старой строке 5823).
- Не добавил ни одной новой ошибки tsc/eslint (проверял).

## Что НЕ сделано в этой фазе

- Кнопка «Создать презентацию» осталась как была — её уберём в Phase 3.
- Под-табы (Слайды / Дизайн / AI) — Phase 3.
- Помесячные ключи `YYYY-MM` — Phase 2.
- AI-инсайты как отдельная сущность в БД — Phase 4.
- Анимация эмодзи (Drift / Fall) — Phase 5.

---

## Как применить (PowerShell)

> Все команды выполняются в корне твоего локального репо `tracker-app`.

### 1. Сделай резервный коммит ПЕРЕД заменой

```powershell
git status
git add -A
git commit -m "backup before phase 1 wysiwyg patch"
```

### 2. Распакуй архив прямо в корень проекта

В архиве структура `src/lib/...` и `src/app/...` совпадает с твоим проектом. Распакуй с **перезаписью** существующих файлов:

```powershell
# Если используешь Windows Explorer — открой ZIP, скопируй папку src и
# выбери "Replace files in destination" когда спросит.
# Через PowerShell:
Expand-Archive -Path .\phase-1-wysiwyg.zip -DestinationPath . -Force
```

После этого должны:
- появиться два новых файла: `src\lib\presentation-renderer.tsx`, `src\lib\presentation-export.tsx`
- замениться один файл: `src\app\page.tsx`

### 3. Проверь что в зависимостях есть `react-dom`

Должен быть (он у тебя уже есть в `package.json` — в зависимостях `react-dom: ^19.0.0`). Из него мы используем `react-dom/server` — это стандартный side-export, ничего ставить дополнительно не нужно.

### 4. Удали старый orphan-файл

```powershell
Remove-Item src\lib\slides.ts
```

Этот файл не использовался нигде в проекте (я проверял через `grep`), он остался от ранней версии. Если оставить — ничего не сломается, но мусор.

### 5. Проверь, что локально билдится

```powershell
bun install         # на всякий случай, если bun.lock что-то двинул
bun run lint        # должен пройти как раньше — я не добавил новых ошибок
bun run dev         # запусти и зайди во вкладку «Презентация»
```

**Критерий успеха визуально:** перейди в любой месяц с задачами → нажми «Презентация» в шапке → перелистай слайды → нажми «Скачать HTML» → открой скачанный файл в браузере. **Превью в приложении и скачанный HTML должны выглядеть одинаково**, отличие только в навигации внизу (стрелочки/точки) — это норма, она в превью на React-кнопках, а в HTML на ванильном JS.

### 6. Закоммить и запуш

```powershell
git add -A
git commit -m "Phase 1: unified WYSIWYG slide renderer (preview = export)"
git push
```

Netlify подхватит и задеплоит.

---

## Если что-то сломалось

1. Откати: `git reset --hard HEAD~1`
2. Скажи мне что именно сломалось:
   - Build error на Netlify? → пришли логи Netlify
   - tsc-ошибка? → пришли её текст
   - Презентация выглядит криво? → пришли скриншот превью и скриншот скачанного HTML, и я сравню

---

## Что внутри новых файлов (для понимания)

### `src/lib/presentation-renderer.tsx`

Главный экспорт — компонент `<PresentationSlide slide={…} theme={…} aiConclusion={…} />`. Принимает один из 7 типов слайдов и рисует его. Все стили — inline (через `style={{...}}`), без Tailwind, потому что экспорт не имеет доступа к Tailwind-компилятору. Тема (`PresentationTheme`) собирается через `buildTheme(accentHex, presBg)`.

Также экспортирует `<PresentationBgLayer />` — слой с эмодзи и паттерном (используется и в превью и в экспорте).

### `src/lib/presentation-export.tsx`

Главный экспорт — функция `renderPresentationHtml(slides, presBg, aiConclusion): string`. Берёт ровно те же React-компоненты, что и превью, прокручивает через `react-dom/server`'s `renderToStaticMarkup`, оборачивает в HTML-shell с навигацией (стрелки + точки + клавиатура) и возвращает строку HTML, готовую к сохранению через Blob.

### `src/app/page.tsx`

В импортах добавлены пять новых имён, локальный `SlidePreview` стал тонким, `buildSlidesHTML` удалён, `handleExportSlidesHTML` теперь зовёт `renderPresentationHtml`. Никакая другая логика не тронута.

---

## Что дальше — Phase 2

Помесячные ключи (`YYYY-MM` вместо `0..11`) — миграция структуры данных. Это будет следующий ZIP. Жди сигнала «Поехали Phase 2».
